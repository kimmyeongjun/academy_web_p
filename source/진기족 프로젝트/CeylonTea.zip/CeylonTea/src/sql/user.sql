CREATE TABLE USERS 
(
	userid     VARCHAR2(30) NOT NULL PRIMARY KEY,
	NAME       VARCHAR2(100) NOT NULL,
    gender     VARCHAR2(10),
	city       VARCHAR2(30)
);



select * from tab;

select * from alllectures where p_name='����ȯ';

delete from alllectures;

